globalThis.fetch=async resource=>{throw Error('Red exterior bloqueada en auditoría local: '+new URL(String(resource?.url??resource)).hostname);};
