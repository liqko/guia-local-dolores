import {readFileSync,writeFileSync} from 'node:fs';
import {Session} from 'node:inspector/promises';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const repo=resolve(process.argv[2]??'.');
const {fixture,city}=await import(pathToFileURL(resolve(repo,'tests/efemerides140/fixture.mjs')));
const path=resolve(repo,'worker/worker206.txt');
const code=readFileSync(path,'utf8');
const session=new Session();
const runs=[];
session.connect();
await session.post('Profiler.enable');
await session.post('Profiler.startPreciseCoverage',{callCount:true,detailed:true});
const key='gld-cotejo-worker206.mjs';
const nativeFetch=globalThis.fetch;
const nativeLog=console.log;
let f;
globalThis.fetch=(...args)=>{assert.ok(f,'red exterior bloqueada');return f.network(...args);};
console.log=()=>{};
const collect=async(label,status,accepted,counts)=>{
 const {result}=await session.post('Profiler.takePreciseCoverage');
 const worker=result.find(s=>s.url===key);
 runs.push({label,status,accepted,counts,ranges:(worker?.functions||[]).map(x=>x.ranges[0]).filter(x=>x.count>0)});
};
try {
 const w=await import('data:text/javascript;base64,'+Buffer.from(code+'\n//# sourceURL='+key+'\n').toString('base64'));
 await collect('carga del módulo',null,true,{});
 const scenarios=[
  ['versión','/',{},200],
  ['territorio público','/territory/public',{auth:false},200],
  ['territorio administración','/superadmin/territory',{},200],
  ['territorio administración local','/superadmin/territory',{role:'ADMIN_LOCAL'},200],
  ['territorio crear sin sesión','/superadmin/cities/create',{auth:false,method:'POST',body:{item:city('B')}},401],
  ['territorio crear sin permiso','/superadmin/cities/create',{role:'ADMIN_LOCAL',method:'POST',body:{item:city('B')}},403],
  ['territorio crear','/superadmin/cities/create',{method:'POST',body:{item:city('B')}},200],
  ['territorio guardar idéntico','/superadmin/cities/A',{method:'PATCH',body:{item:city('A')}},200],
  ['territorio editar','/superadmin/cities/A',{method:'PATCH',body:{item:city('A','Editada')}},200],
  ['territorio reconstruir','/superadmin/territory/rebuild-cache',{method:'POST',body:{}},200],
 ];
 for(const [label,url,options,expected] of scenarios) {
  f=fixture(w.GldPublicCache119,{cities:[city('A')]});
  let pass=false;
  let status;
  try {
   const out=await f.call(w.default,url,options);
   status=out.status;
   pass=status===expected;
   if(!pass) process.stderr.write(label+': '+JSON.stringify(out.result).slice(0,550)+'\n');
  } catch(error) { process.stderr.write(label+': '+error.message+'\n'); }
  await collect(label,status,pass,{...f.counts});
 }
 f=fixture(w.GldPublicCache119,{cities:[city('A')]});
 f.fail.publicPut=1;
 const result=await f.call(w.default,'/superadmin/cities/create',{method:'POST',body:{item:city('B')}});
 await collect('territorio guardar con publicación fallida',result.status,result.status===503,{...f.counts});
 f.evict();
 f.reset();
 const recovered=await f.alarm();
 await collect('territorio recuperar desde alarma',null,recovered&&f.packet().ciudades.some(c=>c.ciudad_id==='B'),{...f.counts});
} finally {
 globalThis.fetch=nativeFetch;
 console.log=nativeLog;
 await session.post('Profiler.stopPreciseCoverage');
 await session.post('Profiler.disable');
 session.disconnect();
}
writeFileSync(process.argv[3]??'cobertura-worker.json',JSON.stringify(runs));
for(const r of runs) console.log(r.label,r.status,r.accepted,r.ranges.length);
assert.ok(runs.some(r=>r.ranges.length));
