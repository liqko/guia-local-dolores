import argparse,collections,hashlib,json,zipfile
from pathlib import Path
p=argparse.ArgumentParser()
for arg in ['entrada','fuentes','salida']:p.add_argument(arg,type=Path)
args=p.parse_args()
name='CADENAS_DEPENDENCIAS_PASO_3.json'
with zipfile.ZipFile(args.entrada) as z: files={n:z.read(n) for n in z.namelist()}
e=json.loads(files[name])
actions={a['AUD']:a for a in e['acciones']}
tables=e['sitios']
def aud(n):return f'AUD-{n:05}'
def text(file,num):
    if file not in sources:sources[file]=(args.fuentes/file).read_text().splitlines()
    return sources[file][num-1].strip()
sources={}
worker='worker/worker206.txt'
gh='plataforma/administracion.html'
for file,markers in {
 worker:{12495:'/save',12503:'stageAdvertiserSaveInternal',12684:'(save|commercial|profile|sedes',8263:'saveAdminCatalogV2',
     8286:'db.patch(def.collection',9290:'saveAdminCatalogV2',8180:'adminSubscriberDetailV2',
     10766:'return json({success:true,sin_limites',10774:'patchGuideAdminFieldsV2',11342:'/superadmin/ephemerides/upcoming',
     1186:'cache.get(PUBLIC_KEY)',1193:'cache.get(ADMIN_KEY)',13220:'routeAtomicAdvertiserInternal',
     13320:"match[2]==='responsables'",11415:'request.method===\'GET\'',9719:'rolePolicy155(cache)',
     11338:'/superadmin/birthdays',1492:"eventsCityKey('VIRTUAL')",2607:'const city=',11070:'archiveTermsV81'},
 gh:{512:'ghSaveAdvertiserDelta_',524:"buscar_suscriptores:'/subscribers/search'",583:"+'/save'",2085:"actualizar_anunciante_comercial",
     2155:'ghGuardarAmbitoCampos',2191:'ghGuardarInfoAnuncianteCupos_',2994:"'guardar_catalogo'",3181:'listar_catalogo',
     3194:'guardar_catalogo',1189:'return;'},
 'plataforma/gh-calendario.js':{25:"get('/superadmin/birthdays'",27:'ghBirthdayRefreshV83',34:"get('/superadmin/ephemerides/upcoming"},
 'plataforma/gh-terminos.js':{10:"action:'publicar'",16:'suscriptor_id:id'},
 'plataforma/gh-listados.js':{92:"load('promos'",78:"'/listados/prepare?tipo='+d.kind",84:"'/listados'"},
}.items():
    for line,marker in markers.items():
        assert marker in text(file,line),(file,line,marker,text(file,line))
rules={}
def add(ids,checked,explanation,exclusion,flow):
    for n in ids:
        assert n not in rules
        rules[n]=(checked,explanation,exclusion,flow)
# Scope is the exact original site set. The checks below cannot resolve another action
# just because it shares a call adapter.
catalog=[87,112,113,118,119,120,121,124,125,127]
add(catalog,[], '','El botón invoca guardar_catalogo. El paquete de ficha y los buscadores se expandieron desde el adaptador compartido; son otras acciones.',
    'Tras validación o cancelación, POST /superadmin/catalogs/:tipo con un solo registro por solicitud. saveAdminCatalogV2 actualiza la colección del tipo, su copia administrativa, la del módulo si existe y la invalidez del paquete fijo. El borrado de nivel es desactivación lógica. Prueba local: al agregar una prestación por primera vez, el registro ya está en la copia local y la comparación omite el POST; editarlo sí emite POST.')
add([111],[12489,1753,1755,4875,4902,4903,4910,5078,5088,6190,6193,6207,6215,6301,6307,6315,6316,6358,7582,7586,7621,7625,7716,8473],
 'La ruta de guardado de Gran Hermano combina datos comerciales, perfil y sedes modificados. Actualiza las copias según los campos presentes y el estado anterior.',
 'La ruta /save de Gran Hermano excluye la rama /commerce de titular, búsqueda y actualización antigua del segmento en la rama comercial. La lectura de reglas pasa false a la recuperación.',
 'Un POST de cambios y revisiones, tras comparar con la ficha. El coordinador por anunciante atiende si está disponible; el despachador interno valida rol y revisiones y confirma los cambios por lote. Los destinos son anuncios, administración, sedes y sus copias.')
add([157],[],'','El clic abre la ficha del suscriptor, nunca llama al guardado del anunciante ni al buscador.',
    'detalleSus → GET /superadmin/subscribers/:id → subscriberDetailV2 lee proyección de cuenta y relaciones (5163–5170, 8176–8180).')
add([86,128],[1193],'Puede leer Territorio para completar las opciones de ciudad.',
    'La consulta o edición de Nodos usa /superadmin/catalogs/nodos, no el guardado de una ficha ni la búsqueda de cuentas.',
    'Cargar consulta Nodos y, si faltan ciudades en memoria, Territorio. Guardar compara cambios, actualiza la colección de Nodos y sus copias si corresponde y vuelve a listar.')
add([24,25],[],'','El alias de preparar ejecuta actualizar cumpleaños. La ruta de efemérides corresponde a otro control.',
    'GET /superadmin/birthdays consulta el listado diario de suscriptores, requiere superadministración y filtra fechas de la semana.')
add([26,27],[11343,11347,1193],'Consulta el catálogo y las copias de efemérides de las ciudades seleccionadas.',
    'Fuera de estos sitios no se añade evidencia.',
    'Consulta Territorio administrativo si faltan ciudades y GET /superadmin/ephemerides/upcoming. Reutiliza la consulta diaria salvo actualización forzada.')
add([34],[],'','GET retorna la excepción antes de escribir y antes de publicar cambios en la copia de Guía.',
    'Lee el índice de anunciantes autorizado y la configuración de Eventos Free del anunciante seleccionado.')
add([36],[],'','Aunque llama patchGuideAdminFieldsV2, el cambio sólo contiene configuraciones y marcas. El filtro 4882–4886 no encuentra campos permitidos y retorna antes de leer o publicar las copias de Guía.',
    'POST valida el ámbito y guarda la excepción de Eventos Free en anunciantes_administracion sólo si cambió.')
add([40],[351,381,385],'GET del listado consulta manifiesto, referencias y deltas si el índice está listo.',
    'Los sitios de preparación requieren POST a /listados/prepare.',
    'Actualizar promociones usa el directorio de Gran Hermano, fuerza lectura y muestra si falta la copia.')
add([41],[351,370,371,374,376,377,381,385],'POST prepara el índice si falta y avanza página a página; GET posterior lee manifiesto, referencias y deltas.',
    'Sin exclusiones en los sitios cotejados.','Preparar requiere confirmación y permisos. Puede leer la colección y publicar copias, luego recarga el listado.')
add([82],[9706,9725,9726],'Actualiza las reglas del perfil y su copia como cuenta principal; después vuelve a leerlas.',
    'La rama /superadmin/access muta una asignación individual, separada de /superadmin/roles.',
    'Configurar roles usa POST /superadmin/roles; la lectura posterior usa GET.')
add([83],[9706],'GET sólo consulta la política de roles.','POST de reglas y /superadmin/access son otras rutas o métodos.',
    'Lee la copia de reglas por perfil o los valores iniciales si falta la copia.')
add([88],[11035,11036,11038,11040,11041,11042],'Lee vigencia y conserva la versión anterior. Si cambia, publica la nueva copia e historial. En caso de conflicto de creación comprueba la versión ya archivada.',
    'Sin exclusiones en los sitios cotejados.','POST de publicar términos y GET posterior de término vigente e historial.')
add([89],[11035,11036],'La consulta por suscriptor lee historial de recibos y la versión correspondiente. Puede reconstruir una copia puntual de una versión que falta (11059).',
    'No crea términos ni archiva una nueva versión. archiveTermsV81 pertenece a publicación.',
    'GET /superadmin/advertiser-terms con suscriptor_id; lee la cuenta y los recibos existentes.')
add([150,979],[1186],'GET consulta la copia territorial pública si el cliente necesita cargar ciudades.',
    'Sin exclusiones en el sitio cotejado.','Destino /territory/public; copias locales pueden evitar la petición.')
add([1],[],'','Los cuatro sitios pertenecen a saveAdvertiserRelation155 y requieren el sufijo responsables. La solicitud es panel-access, con una rama separada.',
    'Abrir panel: POST panel-access verifica sesión y alcance, obtiene ficha y emite la credencial para el panel.')
add([171],[1492],'Consulta el paquete local a la ciudad y el virtual cuando corresponde.',
    'Sin exclusiones en los sitios cotejados.','GET /events-new, action=getevents, sólo si hay ciudad seleccionada.')
add([172],[1193,1492],'Consulta Territorio al iniciar y eventos públicos cuando hay ciudad.',
    'Sin exclusiones en los sitios cotejados.','Inicialización de Gran Hermano con consultas de arranque; la ruta /superadmin/territory tiene copia general o filtro de administrador local.')
add([173],[1193],'La ruta administrativa general lee el catálogo; el perfil local obtiene sólo ciudades autorizadas de la copia pública.',
    'Sin exclusiones en el sitio cotejado.','GET /superadmin/territory al cargar la lista de ciudades.')
add([548],[],'','El texto fijo de recuperación no transporta referencia de revisión ni el prefijo reconocido por reviewReference102.',
    'POST /support/requests con tipo RECUPERACION; registra y vincula la solicitud de acceso, sin consultar una publicación apelada.')
add([657],[],'','El GET de territorio devuelve la proyección antes de validar o modificar vínculos y actualizar el índice.',
    'Abrir Mis ciudades consulta /suscriptores/territory si la sesión todavía no cargó sus datos.')
add([658],[11379,11394,11436,5287,5755,5760],'Valida residencia y vínculo; escribe perfil e índice si cambian. El render posterior puede cargar favoritos bajo la sesión.',
    'Sin exclusiones en los sitios cotejados.','Guardar Mis ciudades envía POST /suscriptores/territory y vuelve a mostrar la cuenta.')
add([655,677,977],[],'','Perfil consulta action=perfil. Logout limpia sesión y vuelve a elegir ciudad. El llamado de arranque renderSession(false) omite Favoritos y la carga posterior tiene su propia entrada (1490).',
    'Se conserva la lectura de perfil autenticado, cambio de página o carga de autorizaciones según la acción.')
add([916],[1388],'Consulta el paquete publicado de promociones por ciudad si el paquete del cliente no alcanza.',
    'Sin exclusiones en el sitio cotejado.','loadData → GET /promos → getPromosCity.')
add([28],[],'','La acción ciclo retorna desde routePublicV12 con su paquete farmCityKeyV2. Los sitios pendientes son del flujo de turnos, reconstrucción o publicación.',
    'Consultar Farmacias requiere seleccionar ciudad; GET /farmacias?action=ciclo lee farmCityKeyV2 y devuelve 503 si falta la copia.')

add([77],[8383,8386,8388,8676,8679,8681,8701,8702],
 'Guarda coeficientes cuando cambia el valor. La cotización posterior consulta precios y coeficientes y puede reconstruir sus copias.',
 'Sin exclusiones en los sitios cotejados.', 'POST /superadmin/sales/coefficients y recálculo condicional mediante POST /superadmin/sales/quote. El lote conserva validación de rol, revisión y parámetros (8684–8739).')
add([344],[13355],'Busca el correo en el índice de suscriptores activos de una cuenta autorizada.',
 'GET /commerce/team/search retorna antes de listar relaciones o guardarlas.',
 'Buscar integrante llama GET /commerce/team/search. El propietario del anuncio debe estar activo.')
add([346],[13278,13299],'Carga anuncio, administración y relaciones existentes. Valida propietario, rol, permisos y revisión; confirma una asignación modificada.',
 'POST /commerce/team/responsables retorna antes de las ramas GET de búsqueda y listado.',
 'Guardar equipo llama POST /commerce/team/responsables tras comprobar el formulario, luego actualiza el estado local.')
add([348],[13358,13360],'Lista relaciones de la cuenta, lee proyecciones de personas y administración de la ficha. La lectura base puede usar un adaptador de caché.',
 'GET /commerce/team no activa búsqueda ni guardado.',
 'El montaje con contexto de propietario llama load y GET /commerce/team; si ya cargó o hay solicitud pendiente retorna.')
add([697],[11035,11038,11040,11041,11042,11092],
 'Lee términos vigentes, archiva la versión sólo si falta y registra aceptación cuando no estaba registrada.',
 'La configuración e historial administrativo corresponden a /superadmin/advertiser-terms. El botón de aceptación usa /advertiser/terms.',
 'Entrar tras aceptar consulta vigencia si la pantalla la había recibido con error y envía POST con versión y hash. El Worker cubre sesión personal y casos de versión cambiada.')
mail_request=[257,506,669,671]
add(mail_request,[5812],'Envía la solicitud de código mediante el servicio de correo. El puente devuelve la respuesta del servicio.',
    'La consulta de cuenta y actualización de credenciales del puente requieren una confirmación con código. Los otros sitios pertenecen a acciones distintas de /suscriptores.',
    'POST /suscriptores con solicitar_recuperacion o solicitar_verificacion según botón; requiere dirección válida.')
add([258,507,668,672],[5812,5821,5828,5755,5760],
    'Si el servicio confirma el código, localiza la cuenta, actualiza verificación o contraseña si cambió y actualiza el índice. Restablecer revoca la sesión.',
    'El puente de correo procesa la acción enviada. Alta, favoritos y eliminación tienen despachos aparte.',
    'POST /suscriptores con restablecer_clave o confirmar_verificacion; validación local y en el Worker.')
add([254,260],[5625],'El ingreso puede cargar autorizaciones si no las reúne la copia de sesión. La operación queda condicionada al acceso válido.',
    'Login V2 atiende antes de la implementación anterior y de las demás acciones del mismo endpoint.',
    'POST /suscriptores login → comprobación de credenciales y estado de cuenta → sesión; puede continuar al módulo previamente elegido.')
add([264],[5316],'Si hay sesión válida, registra el favorito de ciudad.',
    'El cuerpo fija agregar_favorito. Quitar, login y editar datos requieren otros valores de action.',
    'Botón de ciudad en favoritos → POST /suscriptores agregar_favorito → suscriptor_favoritos.')
add([265],[5462,5466,5755,5760],'Verifica ciudad activa en la copia territorial, guarda ciudad predeterminada y actualiza el índice de cuentas.',
    'El cuerpo fija actualizar_ciudad, no alta ni cambio de credenciales.',
    'Guardar ciudad predeterminada desde Carcasa solicita POST /suscriptores actualizar_ciudad.')
add([511],[5478,5481],'Con sesión, obtiene cuenta, valida contraseña actual, guarda la nueva y revoca sesiones.',
    'Cambiar clave autenticada no usa el puente de recuperación ni modifica otros datos de la cuenta.',
    'POST /suscriptores cambiar_clave. La pantalla solicita reingreso después de confirmar el resultado.')
add([546],[],'',
    'Solicitar anuncio tiene un despacho anterior al panel de cuentas. No activa los candidatos de inicio, correo, edición o favoritos atribuidos por compartir /suscriptores.',
    'POST /suscriptores solicitar_anunciante. Reclamar valida anuncio existente y escribe solicitud. Crear valida territorio, reglas y datos, guarda anuncio y sedes y procesa su estado de publicación (10935 y siguientes).')
add([667],[11379,11394,5701,5726,5755,5760,5812],
    'Alta comprueba residencia, vínculo y cuenta preexistente; guarda cuenta e índice y después solicita código al servicio de correo.',
    'La creación usa createSubscriberV3 y no el módulo legado. Solicitar el código no confirma ni cambia una cuenta existente.',
    'GET territory-schema habilita el formulario; POST crear, luego POST solicitar_verificacion si el alta se confirma.')
add([651],[5329,5333,5287],'Si el favorito existe, lo elimina. Luego actualiza Mi Guía y consulta la lista según el estado local.',
    'El botón sólo invoca quitar_favorito y la lectura posterior de Favoritos.',
    'POST /suscriptores quitar_favorito seguido de lectura de favoritos.')
add([656],[5455,5755,5760,5287],'Actualiza la cuenta, sincroniza su índice y repinta Mi Guía, que puede pedir favoritos.',
    'El cuerpo fija actualizar_perfil; otros métodos de cuenta no se ejecutan.',
    'Guardar Mis datos valida nombre y parámetros permitidos; POST actualizar_perfil, luego actualiza sesión local.')
add([666],[5625,5812,5287],'Ingreso válido carga autorizaciones según la copia de sesión y puede pedir favoritos. En correo sin verificar solicita que se envíe el código.',
    'La implementación actual de ingreso y el envío de código inicial no recorren la eliminación, el alta ni el cambio de contraseña.',
    'POST login. Si requiere verificación llama solicitar_verificacion. Si abre sesión, muestra Mi Guía y puede leer Favoritos.')
add([676],[5920,5924,5925,5929,5933,5935,5770,5773],
    'Verifica cuenta y confirmación en el Worker, elimina relaciones, favoritos y cuenta, revoca la sesión y actualiza la copia del índice.',
    'routePanelV9 atiende la eliminación con confirmación antes que el código anterior. Tras éxito se limpia la sesión antes de pintar la vista.',
    'La auditoría sólo traza la operación disparada por el botón de confirmación, sin ejecutarla.')
for ids,good,flow in [
    ([397,399,401,581,646,649],[427,428],'Leer Mis solicitudes con sesión; el Worker puede completar una copia ausente de revisiones cerradas. Notificaciones además solicita el feed.'),
    ([415,645],[10612],'Seleccionar una solicitud activa GET conversación, verifica acceso, busca su registro y lee mensajes.'),
    ([416,647],[10612,10625,10626,10627],'Enviar respuesta valida sesión o recibo y que la solicitud esté abierta. Si es nueva la persiste y vuelve a cargar la conversación.'),
    ([398,648],[408,427,428],'Crear solicitud valida identidad y texto. Sólo con referencia de revisión válida consulta la publicación, busca revisiones y actualiza su copia si hace falta.')
]:
    add(ids,good,flow,'Los demás sitios son de acciones GET/POST separadas. Mostrar un botón de respuesta o de conversación no lo ejecuta.',flow)
def check(file,markers):
    for line,marker in markers.items():
        assert marker in text(file,line),(file,line,marker)
check('plataforma/empleo.js',{24:"api('/empleo/publicas?",48:"await panel()",51:"publicList();",54:"ownAction(b.dataset.own)",55:"tipo=empleo",56:"/empleo/admin"})
check(worker,{360:'routeDirectories102',11559:'employment:record',11562:'empPublic109(next)',11596:"path==='/empleo/admin'",13217:'GLD_ACTIONS138.route'})
for n,receiver in [(334,'own-card'),(335,'buscar'),(336,'admin-load'),(337,'admin-next'),(338,'admin-prev'),(339,'admin-prepare'),(340,'admin-list')]:
    assert actions[aud(n)]['entrada']['receiver']==f"el('{receiver}')"
public_employment='Con ciudad, filtra y pagina la copia pública si está disponible y no existe autorización +18. Si falta la copia o corresponde la vista protegida, GET /empleo/publicas → índice laboral de la ciudad. Sin ciudad no hay petición.'
add([325,335],[11550],public_employment,'El formulario, el panel propio y la administración tienen otros oyentes y rutas.',public_employment)
directory='GET /superadmin/listados?tipo=empleo comprueba permiso, lee el manifiesto y, si está preparado, referencias, bloques y cambios para la página solicitada.'
add([336,337,338],[351,381,385],directory,'Paginación y actualización emiten GET. Preparación y moderación son eventos independientes.',directory)
add([339],[351,370,371,374,376,377,381,385],
    'POST /superadmin/listados/prepare?tipo=empleo comprueba permiso y manifiesto, prepara bloques por página si faltan y persiste el progreso o manifiesto final. Después se vuelve a leer el listado.',
    'Este botón no actualiza una publicación ni usa la lista pública.',directory)
add([334],[11550,11559,11562,11563,11566,11611,11612,11614,11623,8473],
    'Pausar, reactivar o eliminar confirman sesión y permisos y actualizan la publicación y sus copias si hay cambio. Se vuelve a GET /empleo/panel, que lee la publicación, el estado de su revisión y coincidencias si aplica.',
    'Renovar y apelar sólo abren formularios. El envío se enlaza a otros eventos, por lo que no ejecuta las ramas de guardar, renovar, o registrar revisión.',
    'Clic delegado según data-own, con salida local o POST /empleo → GET /empleo/panel.')
add([340],[351,381,385,11559,11562,11563,11566],
    'Con confirmación, POST /empleo/admin exige rol superior y verifica estado. Escribe la publicación y sincroniza sus índices, vuelve a leer el listado y, si el contenedor expone el manejador, refresca GET /superadmin/inbox.',
    'La actualización no inicia una preparación del directorio, una solicitud de soporte ni un guardado personal.',
    'Clic delegado según data-admin → aprobar, rechazar, pausar o eliminar → lista paginada y bandeja si el contenedor está integrado.')
check('plataforma/farma_turnos.html',{378:"searchParams.set('action','turnos')",384:"'FARMACIAS'",410:'load();'})
check(worker,{2459:'cache.get("guide:city:v1:',2466:'cache.put(key,next)',2614:'farmTurnosPublicV3',2229:'gldFuncPacket166'})
add([376,377,378,379,843],[2080,2169,2456,2459,2466,8473],
    'Si la ciudad está definida, los turnos consultan ciclos y fichas de la ciudad y pueden actualizar la copia de ciclos si cambió la información de las sedes. Publicidad lee su listado, las ubicaciones y la distribución de FARMACIAS.',
    'Se entrega a prepareFarmSedes una copia de guía ya obtenida, objeto incluso cuando no se encontró. El adaptador público usa action=publicas y excluye catálogos y campañas privadas.',
    'Fecha anterior, hoy, siguiente, selector con fecha o inicialización → GET /farmacias?action=turnos y GET /publicidad?action=publicas&modulo=FARMACIAS.')
check('plataforma/eventos.html',{2031:'fetchJsonConTimeout(eventsEndpointCiudad',2035:'cached||fetchJsonConTimeout(urlBanners'})
add([836],[1492,2080,2169,8473],
    'Si hay ciudad, el paquete público aporta eventos y publicidad; si no basta o está activa la vista +18, se consultan las rutas públicas. El fallback de eventos reúne el índice local y el virtual y el de banners lee listado y distribución.',
    'El inicio no pide un panel ni un contrato de anunciante en la ruta de panel. Publicidad pública y privada son ramas distintas.',
    'Iniciar vista de Eventos → paquete de ciudad o GET /events-new y paquete publicitario o GET /publicidad?action=publicas&modulo=EVENTOS.')
check(gh,{1327:"'/superadmin/cities/'",1367:"method:'DELETE'",1482:"if(name==='eventos')",1511:"if(name==='recientes'",4001:"'/superadmin/publications/recent?offset='"})
check(worker,{94:'edit=path.match',7291:'cities',10933:'source:'})
add([99,100],[],'','POST o PATCH de Territorio pasa primero por el coordinador GLD_ACTIONS138, con respuesta 503 si la vinculación necesaria no está disponible. No cae al guardado heredado.',
    'Editar nombre o estado comprueba selección y permisos. PATCH /superadmin/cities/:id → coordinador → documento Territorio y copias territorial pública y administrativa según el cambio.')
add([103],[],'','La rama de alta usa el coordinador antes de saveCity. Para país o provincia el manejador muestra un aviso y termina antes del POST.',
    'Guardar nueva ciudad valida nombre, país y provincia → POST /superadmin/cities/create → coordinador y copias. País y provincia quedan como contexto existente.')
add([101],[],'','La pausa previa se despacha por PATCH al coordinador. El código congelado sólo declara POST de creación y PATCH de edición para ciudades. Ninguno de los candidatos de saveCity recibe DELETE.',
    'Eliminar exige superadministrador principal y confirmación escrita. Si está activa, pausa por PATCH. Envía DELETE /superadmin/cities/:id y espera eliminada. No se encontró un destino DELETE en el Worker del corte. Defecto estático, sin ejecutar contra datos reales ni asumir qué versión está desplegada.')
add([30],[],'','Las ramas de ghGoView y su extensión requieren otras vistas. Para inicio, ambas cambian navegación y preparan componentes DOM.',
    'Volver al resumen → ghGoView(inicio) → activar vista y ajustar altura. No dispara los destinos Worker atribuidos.')
add([23,31],[],'','Las actualizaciones de catálogos y retiros son otros botones. Mostrar en el DOM el botón Retirar no ejecuta su POST.',
    'Gran Hermano ver recientes carga sólo cuando el contenedor está vacío; Actualizar lo carga directamente. GET /superadmin/publications/recent → sesión y permiso de moderación → índice paginado KV de últimos diez días y copia más reciente de cada publicación.')
check('plataforma/entrada-recordada.js',{28:'action=perfil'})
add([787,852],[1186],
    'Según si hay ciudad explícita, preferida y selector habilitado, puede cargar territorios. Con identidad almacenada, la recuperación consulta perfil y valida que la sesión no haya cambiado.',
    'La consulta que recupera la ciudad preferida es GET /suscriptores?action=perfil y no pide favoritos.',
    'Entrada a Inicio o Carcasa → ciudad por URL, preferencia autenticada, contenedor o selector → carga de Territorio cuando hace falta.')
check(gh,{2863:"'/catalogs/functional-settings'",2871:"'guardar_catalogo'",3418:"'/catalogs/prices'"})
def candidate_lines(action,lo,hi):
    return sorted({tables[item['idSitio']]['linea'] for item in actions[aud(action)]['dependenciasDelArbolSinCadena']
                   if lo <= tables[item['idSitio']]['linea'] <= hi})
add([76],candidate_lines(76,8382,8423),
    'POST revisa permiso y versión. Lee o recupera el único documento de precios. Si cambiaron los valores, guarda ese documento, actualiza la copia e invalida la de Gran Hermano.',
    'El botón envía sólo prices; dibujar adicionales no ejecuta sus eventos ni carga o reconstruye otros catálogos.',
    'Guardar importes → validación de datos y versión local → POST /superadmin/catalogs/prices → planes_precios/CATALOGO.')
add([115],sorted(set(candidate_lines(115,8473,8479)+candidate_lines(115,8585,8625)+candidate_lines(115,8263,8308))),
    'Valida y compara la revisión de reglas. Actualiza la configuración y las copias si cambió, y escribe por separado cada funcionalidad histórica editada.',
    'El adaptador de catálogos sólo recibe guardar_catalogo con tipo funcionalidades, no las otras mutaciones del contrato.',
    'Guardar funcionalidades → POST /superadmin/catalogs/functional-settings → POST /superadmin/catalogs/funcionalidades por fila histórica cambiada.')
check('plataforma/anunciantes.html',{1428:'fetch(',1371:'localStorage.setItem',2703:'gldToggleFavoritoAnunciante'})
add([195],[5316,5329,5333,('plataforma/anunciantes.html',1371),('plataforma/anunciantes.html',1428)],
    'Con sesión el botón calcula agregar o quitar, envía sólo esa acción y actualiza copia local después de respuesta. Sin sesión pide ingreso al contenedor.',
    'Compartir /suscriptores no activa perfil, verificación, alta ni eliminación de cuenta.',
    'Corazón de ficha → POST /suscriptores agregar_favorito o quitar_favorito → persistencia autorizada → estado del botón y copia local.')

# The navigation wrapper installs controls before evaluating the destination.
check('plataforma/gh-listados.js',{4:"actividades:{kind:",84:"'/listados'",89:"oldGo(name,options)",90:"load('free')",92:"prepare('publicidad')"})
check(gh,{1219:'GH_DAILY_ENTRY195?.territory',1498:"name==='publicidad'",1894:"'/free-event-exceptions'",3915:"name==='resumen_planes'",4032:"tipo==='EMPLEO'"})
territory=[1186,1193]
directory_sites=[351,381,385]
fixed=[8250,8251,8383,8386,8388,8473,8476,8478,8632,8640]
def matching(n,values):
    return sorted({tables[x['idSitio']]['linea'] for x in actions[aud(n)]['dependenciasDelArbolSinCadena']
                   if tables[x['idSitio']]['archivo']==worker and tables[x['idSitio']]['linea'] in values})
def by_action(ids,lines,flow,exclusion):
    for n in ids:
        add([n],matching(n,lines),flow,exclusion,flow)
nav_exclusion='El valor de vista y los métodos GET separan la apertura de las acciones de preparación, aprobación, modificación y guardado. Los botones dibujados no ejecutan sus callbacks ahora.'
by_action([14,21],territory+fixed+[5096],
    'Gran Hermano abre Anunciantes y dibuja pendientes con datos ya cargados. Si faltan ciudades o niveles carga territorio o catálogo. El listado extendido busca anunciantes para el rol general aun con pendingOnly. ADMIN_LOCAL no usa esa búsqueda.',
    nav_exclusion)
by_action([15],territory+[5105],
    'Gran Hermano abre Suscriptores, carga territorio si no está disponible y el listado extendido consulta /superadmin/subscribers/search para rol general, salvo página reutilizable. La ruta usa la copia diaria y puede devolver 503 si aún no está preparada.',
    nav_exclusion)
by_action([16,17,32],territory+directory_sites+[5096],
    'Gran Hermano abre Eventos o sus pendientes. Puede leer Territorio. Para rol general, el listado consulta /superadmin/listados por EVENTOS VIP y Free, reutilizando páginas si existen. Para ADMIN_LOCAL, sólo dibuja datos precargados y puede pedir sus excepciones de Eventos Free y el índice asignado.',
    nav_exclusion)
by_action([18,19],territory+directory_sites,
    'Abrir Actividades o Publicidad actualiza la vista y, para rol general, lee el directorio preparado con el tipo correspondiente. Puede consultar Territorio si faltan ciudades. Los resultados precargados y páginas reutilizables evitan su lectura.',
    nav_exclusion)
by_action([22],[],
    'Abrir Soporte y ayuda de acceso activa la vista y muestra su estado. El clic no llama ghCargarSoporteV73. La bandeja se carga desde inicio o con su botón Actualizar solicitudes.',
    nav_exclusion)
by_action([42],fixed,
    'Abrir Ventas selecciona Calculadora y, si la vista no está cargada, carga catálogo de niveles, precios vigentes y reglas generales. Usa el paquete fijo según disponibilidad y reusa niveles si están en memoria. GET de precios y reglas pueden reconstruir sus copias si faltan. El GET de coeficientes pertenece a otra pestaña.',
    nav_exclusion)
by_action([91],fixed,
    'Ver explicación activa Funcionalidades. Si todavía no están dibujadas, carga el paquete fijo si está habilitado o GET de catálogo funcional y de reglas cuando falten. La carga de precios sólo puede ocurrir al reconstruir el paquete fijo.',
    'Se selecciona una pestaña fija. Los POST de configuración y los GET de otras pestañas requieren otra entrada.')
by_action([45],directory_sites,
    'Actualizar listado de Publicidad en Gran Hermano llama el manejador redefinido por gh-listados.js. Con rol general, lee /superadmin/listados?tipo=publicidad si no hay página local. El listado indica si falta preparar su copia.',
    'La redefinición reemplaza /superadmin/publicidad directo. No cambia estado ni guarda anuncios.')
by_action([46],directory_sites+[370,371,374,376,377],
    'Preparar publicidades existentes usa /superadmin/listados/prepare?tipo=publicidad en el manejador redefinido. Pide confirmación y prepara los bloques de la copia por páginas hasta terminar. Después recarga el directorio. El botón se oculta en la vista reconstruida y la ruta conserva su control de rol.',
    'No usa el preparador anterior /publicidad/prepare ni modifica las piezas publicitarias.')
check('plataforma/empleo.js',{13:'fetch('})
for n in [584,585,586]:
    assert actions[aud(n)]['entrada']['file']=='plataforma/paginacion.js'
    add([n],[11550,('plataforma/empleo.js',13)],
        'Si el paginador fue dibujado en Empleo, ejecuta publicList. Puede paginar su copia o GET /empleo/publicas con los filtros. Los otros cuatro módulos paginan listas en memoria.',
        'El paginador llama sólo onChange del módulo que lo instanció. Los handlers de gestión y preparación de Empleo pertenecen a controles separados.',
        'Anterior, Siguiente o número de página → onChange activo → render de Actividades, Promos, Eventos, Anunciantes o Empleo.')
login='plataforma/login.html'
check(login,{4240:'fetch(url',4698:'function pubUiDestination_',4759:'function pubUiReset_',5131:'loadPublicidadUI',7444:'delete gldEditSessions',9407:"action=anunciante",10048:'reloadDashboardModule'})
check('plataforma/publicidad-panel147.js',{10:'gldLoadCommerceProfileForTags147',24:'loadDashboardModule147',54:"loadDashboardModule147('publicidad')"})
# GH sources collide by short symbols in the original tree. Keep the sites and record why separately.
foreign_excluded={('plataforma/administracion.html',536),('plataforma/gh-promos.js',13)}
check('plataforma/administracion.html',{536:'GLD_PUBLICATION_REQUEST143.run'})
check('plataforma/gh-promos.js',{13:'await '})
advertiser_exclusion='El módulo y la acción quedan fijados por el llamador. Los administradores de Gran Hermano y las ramas de escritura de otros módulos no corresponden. La escritura por inicialización del contrato publicitario sólo aplica cuando se abre ese panel y falta su contrato.'
ads_sites=[1186,1414,1753,1755,1770,4420,4430,4431,4440,4441,4444,8473]
events_sites=[1186,1301,1414,1753,1755,1764,4375,4376,4383,8473]
activity_sites=[1186,1414,1753,1755,1767,3755,3763,8473]
by_action([405,412,413],ads_sites+events_sites,
    'Con evento guardado y pestaña Publicidad habilitada, abre el formulario y carga los datos del panel publicitario si faltan. El selector recupera eventos propios cuando no los tiene. Queda seleccionado el ID de origen. No se envía el guardado de una campaña desde este botón.',
    advertiser_exclusion)
by_action([406,411],ads_sites+activity_sites,
    'Con actividad guardada y pestaña Publicidad habilitada, abre el formulario y carga el panel publicitario si falta. Si el selector no tiene actividades las pide al panel Actividades. El botón preselecciona el ID y prepara el formulario.',
    advertiser_exclusion)
by_action([407],[1186,1753,1755,8473],
    'Usar tags lee el campo ya creado. Si no existe, carga GET /commerce?action=anunciante con sesión y relación válida y puede leer el Territorio público. En el Worker usa commerceMaster205, que lee copia duradera y catálogos. Copia los tags al formulario, sin editar el perfil.',
    'Las lecturas del antiguo commercePanelData quedan reemplazadas por la copia duradera de commerceMaster205.')
by_action([449],activity_sites,
    'Actualizar actividades pide GET /actividades?action=getpaneldata con sesión autorizada. Lee catálogo, datos del anunciante, sus actividades y horarios cuando no están integrados. Después usa Territorio para el formulario.',
    advertiser_exclusion)
by_action([466],events_sites+activity_sites,
    'Cambiar destino de publicidad es local salvo EVENTO o ACTIVIDAD. En esos dos casos carga si hace falta el selector de contenido propio con /events-new getPanelData o /actividades getpaneldata.',
    advertiser_exclusion)
by_action([469],[],
    'Cancelar edición de publicidad limpia borrador, destino, título, media y estado de edición local. Llama pubUiDestination_ con destino vacío, que no carga contenido.',
    'Limpiar los campos no ejecuta sus eventos ni inicia guardado.')
by_action([501],[1186,4008,4010,4011,4014,4015],
    'Actualizar Efemérides hace POST /efemerides con getPanelData, que valida sesión y permisos y lee efemérides y cobertura del anunciante. Usa Territorio público para elegir ciudad.',
    advertiser_exclusion)
by_action([516],[1186,1753,1755,3103,3104,8473],
    'Actualizar Promociones hace POST /promos con getPanelData, comprueba acceso al módulo y carga datos del anunciante y promociones propias. Usa Territorio público para los selectores.',
    advertiser_exclusion)
by_action([520],[1186,1414,4478,4506,4510,4511,4583,4584],
    'Actualizar Farmacias hace POST /farmacias getPanelData. Valida acceso, lee ciudades habilitadas, farmacias, ciclos y participantes. Cambiar a la ciudad ya seleccionada filtra localmente estos datos.',
    advertiser_exclusion)
by_action([531,534],events_sites,
    'Actualizar Eventos Free o Eventos hace POST /events-new con getFreeEventsPanelData o getPanelData y comprueba acceso en el módulo concreto. Lee datos del anunciante, eventos propios, catálogos y programación; usa Territorio y el listado público de partners si hace falta.',
    advertiser_exclusion)

for n,(good,reason,excluded,flow) in rules.items():
    a=actions[aud(n)]
    items=a['dependenciasDelArbolSinCadena']
    selected={(worker,line) if isinstance(line,int) else line for line in good}
    def location(item):
        site=tables[item['idSitio']]
        return site['archivo'],site['linea']
    assert items and all(location(i)[0]==worker or location(i) in selected or (n in {405,406,411,412,413,449,466,469,501,516,520,531,534} and location(i) in foreign_excluded) for i in items),(n,items)
    locations={location(i) for i in items}
    assert selected<=locations,(n,sorted(selected-locations))
    a['cotejoDeRama']={'familia':'cotejo_por_guardas','cadena':flow,'sitios':[
        {**d,'resultado':'comprobado_condicional' if location(d) in selected else 'descartado_por_guarda',
          'motivo':reason if location(d) in selected else excluded}
        for d in items]}
    a['dependenciasDelArbolSinCadena']=[]
pending=[a['AUD'] for a in actions.values() if a['dependenciasDelArbolSinCadena']]
assert len(pending)==177-len(rules)
e['rondaCompleta']={'inicial':177,'cotejadas':sorted(aud(n) for n in rules),'pendientes':pending,
 'alcance':'Cotejo de los candidatos de dependencia del árbol sobre el código congelado. Las condiciones se conservan.'}
files[name]=json.dumps(e,ensure_ascii=False,separators=(',',':')).encode()
with zipfile.ZipFile(args.salida,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for n,val in files.items():z.writestr(n,val)
 z.write(__file__,'cotejo-bloques.py')
 test=Path(__file__).with_name('probar-catalogos-paso3.cjs')
 if test.exists():z.write(test,test.name)
print(len(rules),len(pending))
