import collections,json,sys,zipfile
from pathlib import Path
cadenas,activaciones,out=map(Path,sys.argv[1:4])
with zipfile.ZipFile(cadenas) as z: graph=json.loads(z.read('CADENAS_DEPENDENCIAS_PASO_3.json'))
with zipfile.ZipFile(activaciones) as z: evidence=json.loads(z.read('COBERTURA_ACTIVACIONES.json'))
assert graph['revision']==evidence['revision'],(graph['revision'],evidence['revision'])
open_status={'invocador_identificado_sin_entrada','registro_o_asignacion_sin_invocacion_comprobada',
             'declaracion_sin_invocador_resuelto','uso_no_localizado_revision_por_accion'}
orig=[a for a in evidence['filas'] if a.get('estadoDeCobertura') in open_status]
nodes={f['AST']:f for f in graph['funciones']}
assert len(nodes)==len(graph['funciones'])==3625 and len(orig)==1691
actions={a['AUD']:a for a in graph['acciones']}
exact=collections.defaultdict(set)
for action in actions.values():
    for dep in action.get('cotejoDeRama',{}).get('sitios',[]):
        if dep['resultado']=='comprobado_condicional':
            owner=graph['sitios'][dep['idSitio']]['funcion']
            exact[owner].add(action['AUD'])
items=[]
for row in orig:
    key=row['idArbol']
    node=nodes[key]
    linked=set(node['AUD_conCadena'])
    conditional=set(exact[key])
    all_links=linked|conditional
    pending=all_links.intersection(graph['rondaCompleta']['pendientes'])
    assert all_links<=actions.keys()
    items.append({'idAST':key,'ubicacion':row['archivo']+':'+str(row['linea']),
                  'estadoOriginal':row['estadoDeCobertura'],'padre':row.get('padre'),
                  'cadenaDirectaDesdeAUD':sorted(linked),
                  'dependenciaCotejadaCondicional':sorted(conditional),
                  'accionesQueAunTienenSitiosPorResolver':sorted(pending),
                  'activacionOriginal':row.get('activacion')})
counts={'funciones_unicas':len({f['idAST'] for f in items}),
        'con_traza_directa':sum(bool(f['cadenaDirectaDesdeAUD']) for f in items),
        'con_asociacion_condicional_cotejada':sum(bool(f['dependenciaCotejadaCondicional']) for f in items),
        'sin_ninguna_de_esas_dos_evidencias':sum(not(f['cadenaDirectaDesdeAUD'] or f['dependenciaCotejadaCondicional']) for f in items)}
out.write_text(json.dumps({'revision':graph['revision'],'total':len(items),'conteos':counts,
    'alcance':'Cruce por ID AST. Identificar un trayecto estático o condicional en al menos una acción no acredita todas las activaciones de la función.',
    'funciones':items},ensure_ascii=False,separators=(',',':')))
print(counts)
