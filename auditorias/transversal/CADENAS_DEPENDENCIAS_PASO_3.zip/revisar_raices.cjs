const ts=require('typescript');
const fs=require('node:fs');
const path=require('node:path');
const [base, input, output]=process.argv.slice(2);
const entries=JSON.parse(fs.readFileSync(input));
const scripts=new Map();
for(const file of new Set(entries.map(e=>e.start.file))) {
  const raw=fs.readFileSync(path.join(base,file),'utf8');
  const fragments=[];
  if(file.endsWith('.html')) {
    for(const m of raw.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi)) {
      if(/\bsrc\s*=/i.test(m[1]))continue;
      const start=m.index+m[0].indexOf('>')+1;
      fragments.push({raw:m[2],before:raw.slice(0,start).split('\n').length-1,start});
    }
  } else fragments.push({raw,before:0,start:0});
  for (const fragment of fragments) {
    scripts.set('/'+file+'.'+fragment.start+'.js',{...fragment,file});
  }
}
const options={allowJs:true,noEmit:true,noLib:true,target:ts.ScriptTarget.Latest};
const host=ts.createCompilerHost(options);
const get=host.getSourceFile.bind(host);
host.getSourceFile=(name,...rest)=>scripts.has(name)
  ? ts.createSourceFile(name,scripts.get(name).raw+'\nexport {};\n',rest[0],true,ts.ScriptKind.JS)
  : get(name,...rest);
const program=ts.createProgram([...scripts.keys()],options,host),checker=program.getTypeChecker(),found=new Map();
function locate(s,n) {
  return scripts.get(s.fileName).before+s.getLineAndCharacterOfPosition(n.getStart(s)).line+1;
}
for(const s of program.getSourceFiles()) {
  if(!scripts.has(s.fileName)) continue;
  const part=scripts.get(s.fileName);
  const candidates=entries.filter(e=>e.start.file===part.file);
  function walk(n) {
    if(ts.isBinaryExpression(n)&&n.operatorToken.kind===ts.SyntaxKind.EqualsToken &&
      ts.isPropertyAccessExpression(n.left)&&ts.isIdentifier(n.right)) {
      const line=locate(s,n), receiver=n.left.expression.getText(s);
      for(const e of candidates) {
        const root=e.start;
        if(root.line!==line||root.receiver!==receiver||root.event!==n.left.name.text||root.handler!==n.right.text)continue;
        const ds=checker.getSymbolAtLocation(n.right)?.declarations||[];
        if(ds.length!==1)continue;
        const d=ds[0], rewrites=[];
        const binding=checker.getSymbolAtLocation(n.right);
        function checkWrite(x) {
          if(ts.isIdentifier(x)&&ts.isWriteAccess(x)&&checker.getSymbolAtLocation(x)===binding)rewrites.push(x);
          ts.forEachChild(x,checkWrite);
        }
        checkWrite(s);
        if(rewrites.length)continue;
        let fn=d;
        if(ts.isVariableDeclaration(d)&&d.parent.flags&ts.NodeFlags.Const)fn=d.initializer;
        if(!fn||!(ts.isFunctionDeclaration(fn)||ts.isArrowFunction(fn)||ts.isFunctionExpression(fn)))continue;
        if(fn.getSourceFile()!==s)continue;
        const row={AUD:e.id, archivo:part.file,registro:line,nodo:locate(s,fn),offset:fn.getStart(s),expresion:n.getText(s)};
        const values=found.get(e.id)||[];
        found.set(e.id,[...values,row]);
      }
    }
    ts.forEachChild(n,walk);
  }
  walk(s);
}
const result=[...found.values()].filter(rows=>rows.length===1).map(rows=>rows[0]);
fs.writeFileSync(output,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result.map(r=>[r.AUD,r.nodo])));
