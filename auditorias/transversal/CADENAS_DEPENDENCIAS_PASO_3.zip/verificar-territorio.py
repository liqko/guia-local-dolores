import argparse,json,zipfile
from pathlib import Path
parser=argparse.ArgumentParser(description='Vincular las solicitudes territoriales a las guardas comprobadas del Worker')
parser.add_argument('anexo',type=Path)
parser.add_argument('fuente',type=Path)
parser.add_argument('salida',type=Path)
args=parser.parse_args()
zpath=args.anexo
with zipfile.ZipFile(zpath) as z:
    stored={n:z.read(n) for n in z.namelist()}
name='CADENAS_DEPENDENCIAS_PASO_3.json'
out=json.loads(stored[name])
source=(args.fuente/'worker/worker206.txt').read_text().splitlines()
fragments={1704:'territoryPublic({ cache })',1186:'cache.get(PUBLIC_KEY)',7282:'return territoryAdmin',
           1193:'cache.get(ADMIN_KEY)',10782:'cache.get("territorio:public:v1")'}
assert all(token in source[line-1] for line,token in fragments.items())
routes={
 'GET /territory/public':{'despacho':1704,'operacion':1186,'dato':'territorio:public:v1',
    'cuerpo':'territoryPublic','condicion':'Si falta catálogo devuelve 503. La rama sólo consulta la copia territorial.'},
 'GET /superadmin/territory':{'despacho':7282,'operacion':1193,'dato':'territorio:admin:v1',
    'cuerpo':'territoryAdmin','condicion':'La rama general valida sesión. Con rol ADMIN_LOCAL la rama previa consulta territorio:public:v1 y filtra por ciudades autorizadas.',
    'despachoAdminLocal':10781,'operacionAdminLocal':10782}
}
links={}
for action in out['acciones']:
    proofs=[]
    for rec in action['dependenciasConCadena']:
        leaf=out['sitios'][rec['idSitio']]
        if leaf['tipo']!='HTTP' or len(leaf['rutas'])!=1 or leaf['estado']!='backend_candidate': continue
        key=f"{leaf['verbo']} {leaf['rutas'][0]}"
        if key not in routes:continue
        assert leaf['despachoCandidato']
        proofs.append({'sitioDeSolicitud':rec['idSitio'],'referenciaDespacho':key})
    if proofs: links[action['AUD']]=proofs
out['despachosVerificadosPorRuta']={'archivo':'worker/worker206.txt','rutas':routes,'desdeAccion':links}
out['totales']['alcanceDespachosTerritoriales']=len(links)
out['totales']['enlacesDespachosTerritoriales']=sum(map(len,links.values()))
stored[name]=json.dumps(out,ensure_ascii=False,separators=(',',':')).encode()
stored['verificar-territorio.py']=Path(__file__).read_bytes()
with zipfile.ZipFile(args.salida,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for member,data in stored.items():z.writestr(member,data)
print(out['totales']['alcanceDespachosTerritoriales'],out['totales']['enlacesDespachosTerritoriales'])
