const ts=require('typescript');
const fs=require('node:fs');
const source=fs.readFileSync(process.argv[2],'utf8');
const sf=ts.createSourceFile('gh-listados.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const calls=[];
function walk(n){
 if(ts.isCallExpression(n)&&ts.isIdentifier(n.expression)&&['button','navigation'].includes(n.expression.text)){
  const location=sf.getLineAndCharacterOfPosition(n.getStart(sf));
  calls.push({llamada:n.expression.text,linea:location.line+1,columna:location.character+1,
    argumentos:n.arguments.map(x=>x.getText(sf))});
 }
 ts.forEachChild(n,walk);
}
walk(sf);
console.log(JSON.stringify(calls,null,2));
