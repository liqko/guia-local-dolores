const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const file=process.argv[2];
const source=fs.readFileSync(file,'utf8');
const end=source.lastIndexOf('})();');
assert.ok(end>=0);
const calls=[],views=[],elements=new Map();
class Node {
 constructor(tag='div'){this.tagName=tag;this.children=[];this.value='';this.inert=false;this.style={};}
 append(...nodes){this.children.push(...nodes);}
 after(){}
 replaceChildren(...nodes){this.children=[...nodes];}
 querySelectorAll(tag){return flat(this).filter(n=>n.tagName===tag);}
 closest(){return null;}
 setAttribute(){}
 focus(){}
 remove(){}
}
function flat(n){return [n,...(n.children||[]).flatMap(flat)];}
const el=id=>{if(!elements.has(id))elements.set(id,new Node());return elements.get(id);};
el('publicidadesRevisionArea').parentElement={id:'view-publicidad'};
const doc={getElementById:el,createElement:tag=>new Node(tag),body:new Node('body')};
const window={document:doc,addEventListener(){},removeEventListener(){}};window.parent=window;
let accept=true,prepared=true,more=false;
const context={document:doc,window,location:{origin:'https://fixture.invalid'},GH_ADMIN_ACCESS:{rol:'SUPERADMIN'},
 GH_CITIES:[],ghGoView:(...a)=>views.push(['vista',...a]),ghRenderEventos(){},buscarAnu(){},buscarSus(){},
 ghPublicidadLoad101(){},ghPublicidadPrepare101(){},informarAltura(){},confirm:()=>accept,
 ghCargarCiudades:async()=>{},ghGoPending:x=>views.push(['revision',x]),
 detalleAnu:x=>views.push(['anunciante',x]),detalleSus:x=>views.push(['suscriptor',x]),
 ghAdminRequest_:async(path,body,method='GET')=>{
  calls.push({path,body,method});
  if(path.includes('/prepare'))return {continuar:false,procesadas:1};
  if(path.endsWith('/search'))return {results:[{id:'x',suscriptor_id:'u',ciudad_ids:[]}],total:1,next_offset:null};
  return {preparado:prepared,results:[],total:more?20:2,next_cursor:more?'p2':null};
 }};
vm.runInNewContext(source.slice(0,end)+'globalThis.audit={localPage,load,render,search,ensure};\n'+source.slice(end),context);
const {audit}=context;
function get(box,label){const b=flat(box).find(n=>n.tagName==='button'&&n.textContent===label);assert.ok(b,label);return b;}
const flush=()=>new Promise(setImmediate);
function latest(path,method){return calls.filter(x=>x.path===path&&x.method===method).at(-1);}
function render(key,rows,ready=true){audit.render(key,{page:0,data:{preparado:ready,results:rows,total:rows.length}});}
async function run(){
 const local=new Node();local.append(...Array.from({length:12},()=>new Node()));
 let rerenders=0;audit.localPage(local,'fixture','stable',()=>rerenders++);
 assert.equal(get(local,'Anterior').disabled,true);get(local,'Siguiente').onclick();
 assert.equal(rerenders,1);assert.equal(calls.length,0);
 more=true;await audit.load('promos',true,true);get(el('ghPromosList'),'Siguiente').onclick();
 await flush();assert.equal(latest('/listados','GET').body.cursor,'p2');
 calls.length=0;get(el('ghPromosList'),'Anterior').onclick();await flush();assert.equal(calls.length,0);
 more=false;prepared=false;render('promos',[],false);accept=false;
 await get(el('ghPromosList'),'Preparar listado existente').onclick();assert.equal(calls.length,0);
 accept=true;await get(el('ghPromosList'),'Preparar listado existente').onclick();
 assert.equal(latest('/listados/prepare?tipo=promos','POST').method,'POST');
 const promo={id:'P',titulo:'Promo',estado:'PENDIENTE',ciudades:[],anunciante_id:'A'};
 render('promos',[promo]);const box=el('ghPromosList');
 get(box,'Ir a revisión').onclick();assert.equal(views.at(-1)[1],'PROMO');
 get(box,'Ver anunciante').onclick();assert.equal(views.at(-1)[1],'A');await flush();
 for(const [title,action] of [['Aprobar publicación','aprobar'],['Rechazar publicación','rechazar'],['Pausar','pausar'],['Borrar','borrar']]){
  render('promos',[promo]);await get(box,title).onclick();
  assert.equal(latest('/promos','POST').body.action,action);
 }
 render('promos',[{...promo,estado:'PAUSADA'}]);await get(box,'Reanudar').onclick();
 assert.equal(latest('/promos','POST').body.action,'reanudar');
 render('publicidad',[{id:'B',titulo:'Anuncio',estado:'ACTIVA',ciudades:[]}]);
 assert.equal(get(el('ghPublicidadList'),'Borrar').disabled,true);
 await get(el('ghPublicidadList'),'Pausar').onclick();
 assert.equal(latest('/publicidad','POST').body.action,'pausar');
 render('publicidad',[{id:'B',titulo:'Anuncio',estado:'INACTIVA',ciudades:[]}]);
 assert.equal(get(el('ghPublicidadList'),'Pausar').disabled,true);
 await get(el('ghPublicidadList'),'Borrar').onclick();
 assert.equal(latest('/publicidad','POST').body.action,'eliminar');
 await audit.search('anunciantes');get(el('resAnu'),'Ver ficha y permisos').onclick();
 assert.equal(views.at(-1)[0],'anunciante');
 await audit.search('suscriptores');get(el('resSus'),'Ver ficha').onclick();
 assert.equal(views.at(-1)[0],'suscriptor');
 console.log('PASS: paginación local, remota y cacheada; preparación; revisión y ficha; 5 acciones de Promociones; 2 de Publicidad; fichas de búsqueda');
}
run().catch(e=>{console.error(e);process.exitCode=1;});
