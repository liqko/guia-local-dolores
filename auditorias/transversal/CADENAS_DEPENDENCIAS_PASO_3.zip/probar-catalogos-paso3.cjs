const ts=require('typescript'),fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(process.argv[2],'utf8');
const names=['api','ghDifferent_','ghComparable_','ghNuevaPrestacion_','ghGuardarCatalogo','ghGuardarPublicacionNiveles_','ghSaveAdvertiserDelta_'];
const found=new Map();
for(const m of source.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script\s*>/gi)){
 const sf=ts.createSourceFile('gh.js',m[1],ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
 function scan(n){if(ts.isFunctionDeclaration(n)&&names.includes(n.name?.text)){assert.ok(!found.has(n.name.text));found.set(n.name.text,n.getText(sf));}ts.forEachChild(n,scan);}
 scan(sf);
}
assert.equal(found.size,names.length);
const fields=new Map(),requests=[];
const GH_CATALOGOS=[{tipo:'prestaciones',idField:'prestacion_id'},{tipo:'niveles_anunciante',idField:'nivel_id'}];
const GH_CATALOG_CACHE={prestaciones:[],niveles_anunciante:[]};
const answers=['Prestación nueva','prestacion_nueva',''];
const ctx={
 GH_CATALOGOS, GH_CATALOG_CACHE,GH_FIXED_PACKET169:null,GH_CARGA_GENERAL_ID:'GENERAL',GH_CARGA_GENERAL_BASE:{},
 GH_EDIT_BASE:{anunciante_id:'A',nivel:'3',revision_comercial:'r',sedes:[]},
 GLD_CLASSIFICATION:{active:x=>x?.activo!==false},CSS:{escape:s=>s},structuredClone,
 document:{querySelector:s=>fields.get(s),getElementById:s=>fields.get(s)},
 ghRenderCatalogo:(def,rows)=>{for(const r of rows){const id=r[def.idField];fields.set('[data-cat-nombre="'+id+'"]',{value:r.nombre});fields.set('[data-cat-icono="'+id+'"]',{value:r.icono});fields.set('[data-cat-activo="'+id+'"]',{checked:r.activo});}},
 prompt:()=>answers.shift(),alert:msg=>{throw Error(msg);},
 ghPrepararMatrizReglas_:g=>g==='institucional'?new Map([['1',{nivel_id:'1'}],['2',{nivel_id:'2'}]]):new Map(),
 ghPrepararCargaGrupo_:()=>({}),
 ghAdminRequest_:async(...args)=>{requests.push(args); if(args[0].startsWith('/advertisers/'))return {success:true,revision_comercial:'next'};return {success:true};}
};
vm.createContext(ctx);vm.runInContext([...found.values()].join('\n'),ctx);
async function go(){
 ctx.ghNuevaPrestacion_();
 await new Promise(setImmediate);
 assert.equal(GH_CATALOG_CACHE.prestaciones.length,1);
 assert.equal(requests.length,0);
 fields.get('[data-cat-nombre="prestacion_nueva"]').value='Modificada';
 await ctx.ghGuardarCatalogo('prestaciones','prestacion_nueva');
 assert.equal(requests.length,1);assert.equal(requests[0][0],'/catalogs/prestaciones');
 requests.length=0;
 await ctx.ghGuardarPublicacionNiveles_();
 assert.equal(requests.length,2);assert.ok(requests.every(x=>x[0]==='/catalogs/niveles_anunciante'));
 requests.length=0;
 await ctx.ghSaveAdvertiserDelta_({anunciante_id:'A',nivel:'5',sedes:[]});
 assert.equal(requests.length,1);assert.equal(requests[0][0],'/advertisers/A/save');
 assert.equal(requests[0][1].commercial.nivel,'5');assert.equal(requests[0][1].commercial.revision_comercial,'r');
 console.log('PASS: prestación nueva queda en memoria sin POST; editar sí emite POST. Niveles envía un POST por registro. Guardado de ficha emite un POST con versión.');
}
go().catch(e=>{console.error(e);process.exitCode=1;});
