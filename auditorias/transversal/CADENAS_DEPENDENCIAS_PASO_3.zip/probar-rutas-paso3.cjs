const ts=require('typescript');
const read=require('node:fs').readFileSync;
const path=require('node:path');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const root=process.argv[2];
const worker=read(path.join(root,'worker/worker206.txt'),'utf8');
const page=read(path.join(root,'plataforma/administracion.html'),'utf8');
function getter(raw,name,isHtml=false){
 const fragments=isHtml?[...raw.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script\s*>/g)].map(m=>m[1]):[raw];
 const matches=[];
 for(const source of fragments){
  const sf=ts.createSourceFile('snippet.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
  function walk(n){
   if(ts.isFunctionDeclaration(n)&&n.name?.text===name)matches.push(n.getText(sf));
   ts.forEachChild(n,walk);
  }
  walk(sf);
 }
 assert.equal(matches.length,1,name);
 return matches[0];
}
function compile(src,name,ctx){return vm.runInNewContext(src+'\n'+name,ctx);}
async function main(){
 const calls=[];
 const roles={rol:'SUPERADMIN_PRINCIPAL'};
 const toTab=compile(getter(page,'ghVentasSelect172',true),'ghVentasSelect172',{
  GH_ADMIN_ACCESS:roles,ghCoefCargar173:()=>calls.push('coef'),document:{querySelectorAll:()=>[]},informarAltura(){}
 });
 for(const tab of ['calculadora','niveles','funcionalidades','valores'])toTab(tab);
 assert.equal(calls.length,0);
 toTab('configuracion_comercial');assert.deepEqual(calls,['coef']);
 roles.rol='SUPERADMIN';toTab('configuracion_comercial');assert.deepEqual(calls,['coef']);

 const cacheEvents=[],dbEvents=[];
 const cache={get:async k=>{cacheEvents.push(['get',k]);return null;},put:async k=>cacheEvents.push(['put',k])};
 const db={get:async(...args)=>{dbEvents.push(['get',...args]);return {levels:{},reglas:{}};}};
 const ctx={gl:0,GLD_PRECIOS_CLAVE162:'precios',GLD_FUNC_KEY166:'funciones',GLD_COEF_KEY173:'coeficientes',
    gldPreciosNormalizar162:()=>({}),gldCoefNormalize173:()=>({})};
 const prices=compile(getter(worker,'gldLeerPrecios162'),'gldLeerPrecios162',ctx);
 const functions=compile(getter(worker,'gldFuncPacket166'),'gldFuncPacket166',ctx);
 const coefficient=compile(getter(worker,'gldCoefRead173'),'gldCoefRead173',ctx);
 await prices({cache,db,reconstruir:false});await functions(cache,db,false);
 assert.deepEqual(cacheEvents,[['get','precios'],['get','funciones']]);assert.deepEqual(dbEvents,[]);
 await coefficient({cache,db,rebuild:true});
 assert.deepEqual(dbEvents,[['get','configuracion_plataforma','COEFICIENTES_COMERCIALES']]);
 assert.deepEqual(cacheEvents.slice(-2),[['get','coeficientes'],['put','coeficientes']]);

 const log=[];
 const conversation=compile(getter(worker,'routeSupportConversationV74'),'routeSupportConversationV74',{
    supportActorV74:async()=>({ok:true,admin:true}),json:(body,status=200)=>({body,status}),
    knownReviews102(){throw Error('La rama de reseñas no pertenece a la conversación');},hmac:async()=> 'fixture'
 });
 const fixtureDb={get:async(...a)=>{log.push(['db-get',...a]);return {estado:'ABIERTA'};},
  queryEqual:async(...a)=>{log.push(['query',...a]);return [];},patch:async(...a)=>log.push(['patch',...a.slice(0,2)])};
 const supportCache={get:async k=>{log.push(['get',k]);return null;},put:async k=>log.push(['put',k])};
 const send=async(route,method,body)=>conversation({path:route,request:{method,json:async()=>body},env:{},
  db:fixtureDb,cache:supportCache,url:new URL('https://fixture.invalid'+route+'?solicitud_id=X')});
 assert.equal((await send('/superadmin/support/conversation','GET')).status,200);
 assert.deepEqual(log.map(x=>x[0]),['get','db-get','query']);
 log.length=0;
 assert.equal((await send('/superadmin/support/reply','POST',{texto:'Respuesta',request_key:'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'})).status,200);
 assert.deepEqual(log.map(x=>x[0]),['get','db-get','get','patch','put']);
 console.log('PASS: pestañas de Ventas por rol; catálogo público sin reconstrucción; coeficientes con recuperación; conversación GET y respuesta POST separadas.');
}
main().catch(e=>{console.error(e);process.exitCode=1;});
