import argparse, collections, hashlib, json, zipfile
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('anexo', type=Path)
parser.add_argument('fuente', type=Path)
parser.add_argument('pruebas', type=Path)
parser.add_argument('salida', type=Path)
args=parser.parse_args()
with zipfile.ZipFile(args.anexo) as z:
    old={n:z.read(n) for n in z.namelist()}
nam='CADENAS_DEPENDENCIAS_PASO_3.json'
out=json.loads(old[nam])
by_id={a['AUD']:a for a in out['acciones']}
sites=out['sitios']
worker='worker/worker206.txt'
headings={worker:{8384:'if(packet?.precios)return packet',8385:'if(!reconstruir)',8475:'if(!withFallback)',8678:'if(!rebuild)',
    8691:"if(request.method==='GET')",10616:"path.endsWith('/conversation')",10620:"path.endsWith('/reply')",
    9183:"db.delete('personal_comercial'",9216:"db.patch('personal_comercial'",9163:"path==='/superadmin/internal-roles/bulk'",9210:"cache.get('territorio:public:v1')",
    10604:'await knownReviews102' ,10648:'await knownReviews102',1886:'reconstruir:false',1887:'ctx.db,false'},
    'plataforma/administracion.html':{3475:"tab==='configuracion_comercial'",3476:"if(tab==='configuracion_comercial')ghCoefCargar173()",
    1032:"'/support/conversation'",1034:"'/support/reply'",3555:"'/sales/coefficients'"},
    'plataforma/login.html':{2239:'async function cargarAltaCompleta_',8532:'/advertisers/claim-options',
    9547:"abrirSolicitudAnunciante_('CREAR')",9559:"abrirSolicitudAnunciante_('RECLAMAR')",
    9563:"abrirSolicitudAnunciante_('CREAR')",9567:"abrirSolicitudAnunciante_('RECLAMAR')",
    9571:"abrirSolicitudAnunciante_('CREAR')",9575:"abrirSolicitudAnunciante_('RECLAMAR')"}}
for file,markers in headings.items():
    lines=(args.fuente/file).read_text().splitlines()
    assert all(mark in lines[i-1] for i,mark in markers.items()),(file,[(i,mark,lines[i-1][:80]) for i,mark in markers.items() if mark not in lines[i-1]])
def valid(lines, reason):
    return {line:('comprobado',reason) for line in lines}
def ruled(lines, reason):
    return {line:('descartado_por_guarda',reason) for line in lines}
coef=valid([8676,8679,8681],'GET de coeficientes autorizado. Si la copia falta, consulta COEFICIENTES_COMERCIALES y repone el caché.')
coef.update(ruled([8383,8386,8388,8701,8702],'Precios de la cotización y escritura de coeficientes pertenecen a otras ramas del despachador.'))
coef_local=ruled(coef,'La pestaña sólo cambia la vista. La llamada a cargar coeficientes exige Configuración comercial.')
claim=valid([1186],'Si no está disponible la copia del cliente, solicita el catálogo territorial público.')
claim.update(ruled([1753,1755,8383,8386,8388,8473,8476,8478],'RECLAMAR carga ciudades y opciones de anuncios. El catálogo de la ficha completa se solicita en CREAR.'))
create=valid([1186,1753,1755,8383,8473],'CREAR solicita Territorio y el catálogo de Guía. Los precios y las reglas se leen de sus copias; getCommerceCatalogs consulta la copia de catálogos si falta la principal.')
create.update(ruled([8386,8388,8476,8478],'El catálogo público pasa false a recuperación de precios y reglas. La reconstrucción del caché desde la base no se ejecuta.'))
open_support=valid([10612],'Lee la solicitud en caché y, si falta, en solicitudes_soporte. Luego consulta solicitudes_soporte_mensajes.')
open_support.update(ruled([10625,10626,10627],'Las operaciones de deduplicación y escritura de mensajes corresponden al POST de respuesta.'))
open_support.update(ruled([427,428],'knownReviews102 pertenece a la bandeja personal o a una apelación específica.'))
reply=valid([10612,10625,10626,10627],'Valida estado, tamaño e idempotencia. Si es nuevo, guarda el mensaje y su marca de deduplicación; luego recarga la conversación.')
reply.update(ruled([427,428],'knownReviews102 pertenece a la bandeja personal o a una apelación específica.'))
rules={}
for aud in (62,63,64,65):rules[f'AUD-{aud:05d}']=('ventas_pestana_local',coef_local)
for aud in (66,78):rules[f'AUD-{aud:05d}']=('ventas_leer_coeficientes',coef)
for aud in (540,542,544):rules[f'AUD-{aud:05d}']=('anunciante_abrir_alta',create)
for aud in (541,543,545):rules[f'AUD-{aud:05d}']=('anunciante_abrir_reclamo',claim)
rules['AUD-00153']=('gran_hermano_abrir_conversacion',open_support)
rules['AUD-00156']=('gran_hermano_enviar_respuesta',reply)

# All ten entries share the same five original candidates. Resolve the verb
# separately for each action, retaining the optional read of public territory.
role_operations={
 'AUD-00052':'guardar','AUD-00053':'eliminar','AUD-00060':'leer','AUD-00061':'leer',
 'AUD-00092':'moderador','AUD-00093':'moderador','AUD-00139':'leer','AUD-00145':'conjunto',
 'AUD-00149':'leer','AUD-00165':'leer',
}
required_routes={
 'guardar':('POST','/superadmin/commercial/personnel'),
 'eliminar':('DELETE','/superadmin/commercial/personnel'),
 'conjunto':('POST','/superadmin/internal-roles/bulk'),
}
for aud,action in role_operations.items():
    reachable={(site['verbo'],route) for term in by_id[aud]['dependenciasConCadena']
               if (site:=sites[term['idSitio']])['tipo']=='HTTP' for route in site.get('rutas',[])}
    assert ('GET','/territory/public') in reachable
    for effect,signature in required_routes.items():
        assert (signature in reachable)==(effect==action),(aud,signature)
    result=valid([1186],'La interfaz puede cargar Territorio público para mostrar las ciudades.')
    for permit,lines,description in (
        ('conjunto',[9095],'El guardado conjunto valida ciudades contra la copia territorial.'),
        ('eliminar',[9183],'Quita la asignación comercial si existe y se cumplen condiciones.'),
        ('guardar',[9210,9216],'El guardado comercial verifica ciudades y actualiza personal_comercial.')
    ):
        result.update(valid(lines,description) if permit==action else
                      ruled(lines,'Exige otra ruta o método: '+required_routes[permit][0]+' '+required_routes[permit][1]))
    rules[aud]=('gran_hermano_roles_'+action,result)

admin=(args.fuente/'plataforma/administracion.html').read_text().splitlines()
load_order=(args.fuente/'plataforma/gh-listados.js').read_text().splitlines()
assert "buscar_suscriptores:'/subscribers/search',buscar_anunciantes:'/advertisers/search'" in admin[523]
assert 'btnBuscarSus' in admin[3955] and 'onclick=buscarSus' in admin[3955]
assert 'btnBuscarAnu' in admin[3956] and 'onclick=buscarAnu' in admin[3956]
assert "if(e.key==='Enter')buscarAnu();" in admin[3958]
assert "'change',buscarAnu" in admin[3959]
assert 'gh-listados.js' in admin[4097]
assert "buscarAnu=()=>search('anunciantes');buscarSus=()=>search('suscriptores');" in load_order[97]
search_group={
 'AUD-00051':'suscriptores','AUD-00069':'anunciantes','AUD-00179':'suscriptores',
 'AUD-00180':'anunciantes','AUD-00182':'anunciantes','AUD-00183':'anunciantes',
}
candidate_sites={d['idSitio'] for d in by_id['AUD-00051']['dependenciasDelArbolSinCadena']}
assert len(candidate_sites)==40
candidate_lines={sites[i]['linea'] for i in candidate_sites}
for aud,domain in search_group.items():
    assert {d['idSitio'] for d in by_id[aud]['dependenciasDelArbolSinCadena']}==candidate_sites
    applicable=5105 if domain=='suscriptores' else 5096
    explanation=('Filtra la copia diaria de suscriptores obtenida mediante el coordinador (8103–8107, 11277–11282).'
                 if domain=='suscriptores' else 'Busca y filtra en la copia del índice de anunciantes (8094–8101).')
    decisions=ruled(candidate_lines-{applicable},'La búsqueda GET '+domain+' no llama al otro buscador, ni ejecuta el guardado de ficha sugerido por el adaptador común. Los clics sobre resultados son entradas independientes.')
    decisions.update(valid([applicable],explanation))
    rules[aud]=('gran_hermano_buscar_'+domain,decisions)

before=[a for a in by_id.values() if a['dependenciasDelArbolSinCadena']]
groups=collections.defaultdict(list)
for a in before:
    keys=tuple(sorted(d['idSitio'] for d in a['dependenciasDelArbolSinCadena']))
    groups[keys].append(a['AUD'])
assert len(before)==207
for aud,(kind,rule) in rules.items():
    record=by_id[aud]
    previous=record['dependenciasDelArbolSinCadena']
    assert {(sites[x['idSitio']]['archivo'],sites[x['idSitio']]['linea']) for x in previous}=={(worker,i) for i in rule},aud
    record['cotejoDeRama']={'familia':kind,'sitios':[
        {**d,'resultado':rule[sites[d['idSitio']]['linea']][0],'motivo':rule[sites[d['idSitio']]['linea']][1]} for d in previous]}
    record['dependenciasDelArbolSinCadena']=[]
pending=[a['AUD'] for a in by_id.values() if a['dependenciasDelArbolSinCadena']]
assert len(pending)==len(before)-len(rules)==177
calls=json.loads((args.pruebas/'botones-ast.json').read_bytes())
assert [x['linea'] for x in calls if x['llamada']=='button']==[32,32,47,57,62,63,64,67,67,68,69,96]
assert [x['linea'] for x in calls if x['llamada']=='navigation']==[33,74,96]
listing=(args.fuente/'plataforma/gh-listados.js').read_bytes()
assert b"b.onclick=fn" in listing
assert b"async function load(key" in listing and b"const d=defs[key]" in listing
selectors=json.loads((args.pruebas/'familias-botones.json').read_bytes())
assert set(selectors)=={'32','47','57','62','63','64','67','68','69','96'}
by_id['AUD-00382']['revisionDirecta']={'estado':'constructor_resuelto_por_boton_y_aparicion',
 'archivo':'plataforma/gh-listados.js','linea':31,'sha256':hashlib.sha256(listing).hexdigest(),
 'sitiosAST':calls,'ramas':selectors,'pruebas':'probar-botones-gh.cjs'}
out['cierreLote']={'inicialAccionesConSitioPendiente':len(before),'cotejadas':sorted(rules),'pendientes':pending,
    'gruposExactosDeSitiosOriginales':[{'AUD':v,'sitios':k} for k,v in groups.items()],
    'gruposIniciales':len(groups),'gruposPendientes':sum(any(aud in pending for aud in v) for v in groups.values()),
    'constructorCerrado':'AUD-00382', 'alcance':'El recuento se limita al cotejo del sitio pendiente en la fuente del corte auditado.'}
assert sum(len(a['dependenciasDelArbolSinCadena']) for a in out['acciones'])>0
old[nam]=json.dumps(out,ensure_ascii=False,separators=(',',':')).encode()
with zipfile.ZipFile(args.salida,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for name,body in old.items(): z.writestr(name,body)
    z.write(__file__,'cerrar-grupos-paso3.py')
    for name in ('inventario-botones.cjs','botones-ast.json','familias-botones.json','probar-botones-gh.cjs','probar-rutas-paso3.cjs'):
        z.write(args.pruebas/name,name)
with zipfile.ZipFile(args.salida) as z: assert z.testzip() is None
print('Cotejadas',len(rules),'antes',len(before),'pendientes',len(pending),'grupos pendientes',out['cierreLote']['gruposPendientes'])
