import argparse,collections,hashlib,json,zipfile
from pathlib import Path

parser=argparse.ArgumentParser(description='Reconstruir cadenas desde el manejador de cada AUD a sus dependencias estáticas con evidencia por salto')
parser.add_argument('audit',type=Path)
parser.add_argument('source',type=Path)
parser.add_argument('output',type=Path)
parser.add_argument('--raices',type=Path)
parser.add_argument('--manual',type=Path)
args=parser.parse_args()
audit=args.audit/'auditorias/transversal'
source=args.source/'auditorias/transversal'
with zipfile.ZipFile(audit/'CATALOGO_MAESTRO.zip') as z:
    catalogue=json.loads(z.read('CATALOGO_MAESTRO.json'))
with zipfile.ZipFile(audit/'COBERTURA_ACTIVACIONES.zip') as z:
    coverage=json.loads(z.read('COBERTURA_ACTIVACIONES.json'))
graph=json.loads((source/'ARBOL_ACCIONES.json').read_bytes())
assert graph['sourceHashes']==catalogue['baseline']['sourceHashes']
assert catalogue['baseline']['revision']==coverage['revision']
assert all(hashlib.sha256((args.source/f).read_bytes()).hexdigest()==v for f,v in graph['sourceHashes'].items())
entries={x['id']:x for x in catalogue['entries']}
trees={x['action']['id']:x for x in graph['trees']}
functions={x['id']:x for x in graph['functionGraph']}
endpoints={x['callId']:x for x in graph['endpoints']}
adj=collections.defaultdict(dict)
leaves=collections.defaultdict(dict)
effect_data={}
route_bridges=collections.defaultdict(list)
for tree in trees.values():
    for n in tree['nodes']:
        if n['type']=='data':
            effect_data[n['callId']]=n
        elif n['type']=='backend_candidate':
            route_bridges[n['from']].append((n['handler'],n['at']))
route_bridges={k:sorted(set(v)) for k,v in route_bridges.items()}
def edge(before,after,site,kind,guards=None,call=None):
    assert before in functions and after in functions and site
    key=(after,site,kind,call)
    adj[before][key]={'desde':before,'hasta':after,'sitio':site,'evidencia':kind,'condiciones':guards,'llamada':call}
def effect(owner,call,kind,**values):
    key=call['id']+':'+kind
    leaves[owner][key]={'funcion':owner,'tipo':kind,'archivo':call['file'],'linea':call['line'],
                        'condiciones':call.get('guards',[]),'metodo':call['method'],**values}
for f in functions.values():
    owner=f['id']
    for call in f['calls']:
        site=f"{call['file']}:{call['line']}"
        if call['kind']=='http':
            e=endpoints.get(call['id'],{})
            effect(owner,call,'HTTP',verbo=e.get('verb'),expresion=e.get('expression'),
                rutas=e.get('candidates') or ([e['target']] if e.get('target') else []),
                estado=e.get('status','sin_ruta_demostrada'),base=e.get('apiBase'),
                despachoCandidato=e.get('worker',[]),destinosCandidatos=route_bridges.get(call['id'],[]))
        elif call['kind']=='data':
            node=effect_data.get(call['id'],{})
            effect(owner,call,'datos',destino=node.get('key'),evidenciaDestino='nodo_datos' if node else 'operacion_sin_argumento_indexado')
        elif call.get('to'):
            edge(owner,call['to'],site,call['resolution'],call.get('guards',[]),call['id'])
        elif call.get('alternatives'):
            effect(owner,call,'despacho_condicionado',posiblesCuerpos=call['alternatives'],
                   estado='falta_seleccionar_llamador_o_instancia')
        elif call['resolution']=='constructor_injected_callback':
            effect(owner,call,'callback_inyectado',estado='depende_de_instancia')
        elif call['resolution'] in {'inaccessible_lexical_function','unknown','external_method'}:
            if call['resolution']=='inaccessible_lexical_function' or call['method'] in {'get','put','postMessage','write','delete','fetch','send','setItem','getItem','request'}:
                effect(owner,call,'destino_pendiente',estado=call['resolution'])
# Add only edges with a receiver or invocation already corroborated by the AST annex.
allowed={'contrato_biblioteca_estandar','propiedad_evento_dom','llamada_vinculada_por_simbolo',
         'global_unica_entre_scripts_clasicos','parametro_invocado_por_receptor','propiedad_callback_usada_por_receptor'}
for row in coverage['filas']:
    for link in row['entradasLocales']:
        if link['desde'] in functions and link['hacia'] in functions and link['clase'] in allowed:
            edge(link['desde'],link['hacia'],link['sitio'],link['clase'],link.get('condiciones'))
assert len(entries)==987==len(trees)
assert set(trees)=={a['start']['id'] for a in entries.values()}
function_positions=collections.defaultdict(list)
for f in functions.values():
    prefix=f"{f['file']}:{f['line']}:"
    if f['id'].startswith(prefix):
        function_positions[f['id'].split(':',3)[0]+':'+str(f['line'])+':'+f['id'].split(':',3)[2]].append(f['id'])
verified_roots={}
if args.raices:
    for evidence in json.loads(args.raices.read_bytes()):
        a=entries[evidence['AUD']]
        assert a['start'].get('entry') not in functions and a['start']['line']==evidence['registro']
        matches=function_positions[f"{evidence['archivo']}:{evidence['nodo']}:{evidence['offset']}"]
        assert len(matches)==1,(evidence,matches)
        verified_roots[a['id']]={**evidence,'destino':matches[0],'tipo':'asignacion_evento_y_simbolo_lexico_verificados'}
missing_roots=[(a['id'],a['start'].get('entry'), a['start'].get('entryId'), a['start'].get('kind'))
               for a in entries.values() if a['start'].get('entry') not in functions and a['id'] not in verified_roots]
print('RAICES',len(missing_roots),len(verified_roots),flush=True)
all_leaves={k:d for group in leaves.values() for k,d in group.items()}
review=json.loads(args.manual.read_bytes()) if args.manual else {}
assert set(review)<=set(entries)
def reachable(start):
    seen={start:None}
    queue=collections.deque([start])
    while queue:
        node=queue.popleft()
        for link in adj.get(node,{}).values():
            dest=link['hasta']
            if dest not in seen:
                seen[dest]=link
                queue.append(dest)
    return seen
def route(start,target,prev):
    trail=[]
    cur=target
    while (link:=prev[cur]) is not None:
        assert link['hasta']==cur
        cur=link['desde']
        trail.append(link)
    assert cur==start
    return list(reversed(trail))
results=[]
matched_rows=collections.defaultdict(list)
closed_sites=collections.Counter()
for aud,a in entries.items():
    start=verified_roots.get(aud,{}).get('destino',a['start'].get('entry'))
    seen=reachable(start) if start in functions else {}
    ends={}
    for fn in seen:
        for key,item in leaves.get(fn,{}).items():
            ends[key]={'ruta':route(start,fn,seen),'dependencia':item}
    tree=trees[a['start']['id']]
    original_effects={node['callId']+':'+('HTTP' if node['type']=='http' else 'datos') for node in tree['nodes'] if node['type'] in {'http','data'}}
    external_hops=[{'idSitio':key,'dependencia':all_leaves[key]}
                   for key in sorted(original_effects-set(ends))]
    present=set(ends)&original_effects
    closed_sites.update({key:1 for key in present})
    for f in seen:
        matched_rows[f].append(aud)
    result={'AUD':aud,'interfaz':a['interface'],'entrada':a['start'],
        'dependenciasConCadena':[{'idSitio':k,**v} for k,v in sorted(ends.items())],
        'dependenciasDelArbolSinCadena':[d for d in external_hops],
        'funcionesAlcanzadas':len(seen),'raizVerificada':verified_roots.get(aud),'revisionDirecta':review.get(aud)}
    results.append(result)
functions_from_annex=[]
for row in coverage['filas']:
    identity=row['idArbol']
    actions=matched_rows[identity]
    functions_from_annex.append({'AST':identity,'AUD_conCadena':actions,
        'sinCadenaDesdeAUD':not actions,'sitiosDirectos':list(leaves.get(identity,{}))})
assert len(functions_from_annex)==3625
assert len({r['AST'] for r in functions_from_annex})==3625
verified=[a for a in results if any(x['dependencia']['tipo'] in {'datos','HTTP'} for x in a['dependenciasConCadena'])]
unlinked=[a for a in results if a['dependenciasDelArbolSinCadena']]
counts={'acciones':len(entries),'entradasSinRaizExacta':len(missing_roots),'raicesRecuperadas':len(verified_roots),'accionesConCaminoAHTTPoDatos':len(verified),
        'accionesConDependenciasDelArbolAunNoEncadenadas':len(unlinked),
        'sitiosDelArbolEncadenadosDistintos':len(closed_sites),
        'enlacesAccionSitioDelArbol':sum(closed_sites.values()),
        'funcionesAnexoAlcanzadas':sum(bool(r['AUD_conCadena']) for r in functions_from_annex),
        'funcionesAnexoSinCadenaDesdeAUD':sum(r['sinCadenaDesdeAUD'] for r in functions_from_annex),
        'funcionesDelGrupo1691Alcanzadas':sum(bool(r['AUD_conCadena']) and 'comprobacionPendiente' in row
                                           for r,row in zip(functions_from_annex,coverage['filas']))}
index_edges={}
edge_register=[]
def encode_edge(x):
    key=json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
    if key not in index_edges:
        index_edges[key]=len(edge_register)
        edge_register.append(x)
    return index_edges[key]
for a in results:
    for rec in a['dependenciasConCadena']:
        rec['ruta']=[encode_edge(x) for x in rec['ruta']]
        assert all_leaves[rec['idSitio']]==rec.pop('dependencia')
    for rec in a['dependenciasDelArbolSinCadena']:
        assert all_leaves[rec['idSitio']]==rec.pop('dependencia')
output={'revision':coverage['revision'],'totales':counts,'acciones':results,'funciones':functions_from_annex,
        'entradasSinRaizExacta':missing_roots,'saltos':edge_register,'sitios':all_leaves,
        'formato':'ruta contiene índices en saltos; idSitio referencia sitios. Las rutas del backend requieren cotejar guardas y parámetros. Las revisiones directas documentan ese contraste por AUD.'}
with zipfile.ZipFile(args.output,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    z.writestr('CADENAS_DEPENDENCIAS_PASO_3.json',json.dumps(output,ensure_ascii=False,separators=(',',':')))
    z.write(__file__,'cadenas_dependencias.py')
    if args.raices:
        z.write(args.raices,'raices-verificadas.json')
        z.write(args.raices.with_name('revisar_raices.cjs'),'revisar_raices.cjs')
    if args.manual:
        z.write(args.manual,'revision-directa.json')
with zipfile.ZipFile(args.output) as z:
    assert z.testzip() is None
print(json.dumps(counts))
